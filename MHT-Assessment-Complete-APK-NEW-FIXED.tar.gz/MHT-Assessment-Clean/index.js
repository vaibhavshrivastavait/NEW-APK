import { registerRootComponent } from 'expo';
import App from './App';

console.log('🚀 MHT Assessment - Testing GitHub App.tsx:', new Date().toISOString());

// Register the original GitHub App component
registerRootComponent(App);